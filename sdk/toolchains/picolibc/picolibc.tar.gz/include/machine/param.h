/* Copyright (c) 2004 Jeff Johnston  <jjohnstn@redhat.com> */
/* Place holder for machine-specific param.h.  */
